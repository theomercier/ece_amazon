<!DOCTYPE html>
<html>
<head>
	<title>ajoutMusic</title>
</head>
<body>

	<form action="ajoutMusicExe.php" method="post">
		<table>
			<tr>
			<td>Nom de la musique :</td>
			<td><input type="text" name="name" /></td>
			</tr>

			<tr>
			<td>Prix de la musique :</td>
			<td><input type="text" name="price" /></td>
			</tr>

			<tr>
			<td>Etat de la musique :</td>
			<td><input type="text" name="shape" /></td>
			</tr>

			<tr>
			<td>Description de la musique :</td>
			<td><input type="text" name="description" /></td>
			</tr>

			<tr>
			<td>Lien vidéo de la musique :</td>
			<td><input type="text" name="videoLink" /></td>
			</tr>

			<tr>
			<td>Quantité a mettre en vente :</td>
			<td><input type="text" name="quantity" /></td>
			</tr>

			<tr>
			<td>Artiste de la musique  :</td>
			<td><input type="text" name="artist" /></td>
			</tr>

			<tr>
			<td>label de la musique :</td>
			<td><input type="text" name="label" /></td>
			</tr>

			<tr>
			<td>Date de sortie de la musique :</td>
			<td><input type="text" name="reDate" /></td>
			</tr>

			<tr>
			<td>genre de la musique  :</td>
			<td><input type="text" name="genre" /></td>
			</tr>

			<tr>
			<td>type de la musique :</td>
			<td><input type="text" name="type" /></td>
			</tr>
			

		</table>

		<input type="submit" value="Valider" />
	</form>

</body>
</html>