<!DOCTYPE html>
<html>
<head>
	<title>choix catégorie</title>
</head>

<body>

	<p>
    Quelle catégorie d'item voulez vous ajouter<br/>
	</p>

	<FORM method="get" action="cible.php">
		<SELECT name="choix">
			<OPTION value ="livre">livre
			<OPTION value ="musique">musique
			<OPTION value ="vetement">vetement
			<OPTION value ="spo_act">Sport et Activité	
		</SELECT>
	<p>
	    <input type="submit" value="Valider" />
	</p>
	</FORM>

</body>

</html>