<!DOCTYPE html>
<html>
<head>
	<title>ajoutLivre</title>
</head>
<body>

	<form action="ajoutVetExe.php" method="post">
		<table>
			<tr>
			<td>Nom du vetement :</td>
			<td><input type="text" name="name" /></td>
			</tr>

			<tr>
			<td>Prix du vetement :</td>
			<td><input type="text" name="price" /></td>
			</tr>

			<tr>
			<td>Etat du vetement :</td>
			<td><input type="text" name="shape" /></td>
			</tr>

			<tr>
			<td>Description du vetement :</td>
			<td><input type="text" name="description" /></td>
			</tr>

			<tr>
			<td>Lien vidéo du vetement :</td>
			<td><input type="text" name="videoLink" /></td>
			</tr>

			<tr>
			<td>Quantité a mettre en vente :</td>
			<td><input type="text" name="quantity" /></td>
			</tr>

			<tr>
			<td>Marque :</td>
			<td><input type="text" name="brand" /></td>
			</tr>

			<tr>
			<td>Type :</td>
			<td><input type="text" name="type" /></td>
			</tr>

			<tr>
			<td>genre :</td>
			<td><input type="text" name="genre" /></td>
			</tr>

			<tr>
			<td>Taille :</td>
			<td><input type="text" name="size" /></td>
			</tr>

			<tr>
			<td>Matiere :</td>
			<td><input type="text" name="material" /></td>
			</tr>

			<tr>
			<td>Couleur :</td>
			<td><input type="text" name="color" /></td>
			</tr>

		</table>

		<input type="submit" value="Valider" />
	</form>

</body>
</html>